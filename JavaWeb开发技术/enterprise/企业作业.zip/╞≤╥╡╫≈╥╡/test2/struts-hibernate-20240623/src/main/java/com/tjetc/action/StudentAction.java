package com.tjetc.action;

import com.opensymphony.xwork2.ModelDriven;
import com.tjetc.domain.Student;
import com.tjetc.service.StudentService;
import com.tjetc.service.impl.StudentServiceImpl;
import org.apache.struts2.ServletActionContext;

import java.util.List;

public class StudentAction implements ModelDriven<Student> {
    private StudentService studentService = new StudentServiceImpl();
    private String msg;

    public String getMsg(){
        return msg;
    }

    private Student student = new Student();

    public Student getStudent() {
        return student;
    }

    public Student getModel() {
        return student;
    }

    public String login() {
        System.out.println(student);
        String studentname = student.getStudentname();
        String password = student.getPassword();
        Student student1 = studentService.findByStudentname(studentname);

        if (student1 == null) {
            msg = "学生不存在";
            return "fail";
        } else {
            if (student1.getPassword().equals(password)) {
                return "success";
            } else {
                msg = "密码错误";
                return "fail";
            }
        }
    }

    public String list() {
        String studentname = student.getStudentname();
        if (studentname == null) {
            studentname = "";
        }
        List<Student> list = studentService.list(studentname);
        System.out.println(list);
        ServletActionContext.getRequest().setAttribute("list", list);
        return "list";
    }

    public String add() {
        System.out.println(student);
        Student student1 = studentService.findByStudentname(student.getStudentname());
        if (student1 != null) {
            msg = "学生名称已经存在";
            return "add";
        } else {
            boolean result = studentService.add(student);
            if (result) {
                return "toList";
            } else {
                msg = "学生新增失败";
                return "add";
            }
        }
    }

    public String findById() {
        Integer id = student.getId();
        student = studentService.findById(id);
        return "update";
    }

    public String update() {
        boolean result = studentService.update(student);
        return "toList";
    }

    public String del() {
        boolean result = studentService.delete(student);
        return "toList";
    }
}
