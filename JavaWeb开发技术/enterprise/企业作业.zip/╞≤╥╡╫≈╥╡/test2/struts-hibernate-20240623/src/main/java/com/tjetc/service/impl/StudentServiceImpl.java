package com.tjetc.service.impl;

import com.tjetc.dao.StudentDao;
import com.tjetc.dao.impl.StudentDaoImpl;
import com.tjetc.domain.Student;
import com.tjetc.service.StudentService;

import java.util.List;

public class StudentServiceImpl implements StudentService {
    private StudentDao studentDao = new StudentDaoImpl();

    public Student findByStudentname(String studentname) {
        return studentDao.findByStudentname(studentname);
    }

    public List<Student> list(String studentname) {
        return studentDao.list(studentname);
    }

    public boolean add(Student student) {
        return studentDao.add(student);
    }

    public Student findById(int id) {
        return studentDao.findById(id);
    }

    public boolean update(Student student) {
        return studentDao.update(student);
    }

    public boolean delete(Student student) {
        return studentDao.delete(student);
    }
}
