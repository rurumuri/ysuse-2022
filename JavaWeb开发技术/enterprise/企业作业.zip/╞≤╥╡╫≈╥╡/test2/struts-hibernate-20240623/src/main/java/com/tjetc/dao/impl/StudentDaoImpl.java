package com.tjetc.dao.impl;

import com.tjetc.common.HibernateUtil;
import com.tjetc.dao.StudentDao;
import com.tjetc.domain.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.io.Serializable;
import java.util.List;

public class StudentDaoImpl implements StudentDao {
    private SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

    @Override
    public Student findByStudentname(String studentname) {
        Session session = sessionFactory.openSession();
        String hql = "from Student where studentname =?";
        Student student = (Student) session.createQuery(hql).setString(0, studentname).uniqueResult();
        session.close();
        return student;
    }

    @Override
    public List<Student> list(String studentname) {
        Session session = sessionFactory.openSession();
        String hql = "from Student where studentname like ?";
        List<Student> list = session.createQuery(hql).setString(0, "%" + studentname + "%").list();
        session.close();
        return list;
    }

    public boolean add(Student student) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            Serializable save = session.save(student);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return false;
    }

    public Student findById(int id) {
        Session session = sessionFactory.openSession();
        Student student = (Student) session.createQuery("from Student where id=?").setInteger(0, id).uniqueResult();
        session.close();
        return student;
    }

    public boolean update(Student student) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            session.update(student);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return false;
    }

    public boolean delete(Student student) {
        Session session = null;
        Transaction transaction = null;
        try {
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            session.delete(student);
            transaction.commit();
            return true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return false;
    }
}
