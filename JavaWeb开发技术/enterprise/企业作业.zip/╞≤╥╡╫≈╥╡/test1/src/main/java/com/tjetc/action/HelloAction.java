package com.tjetc.action;

public class HelloAction {
    public  String execute(){
        System.out.println("hello().....");
        return "hello-result";
    }
}
