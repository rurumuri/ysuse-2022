package com.tjetc.domain;

public class Student {
    private String studentname;
    private String password;

    @Override
    public String toString() {
        return "Student{" +
                "studentname='" + studentname + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
