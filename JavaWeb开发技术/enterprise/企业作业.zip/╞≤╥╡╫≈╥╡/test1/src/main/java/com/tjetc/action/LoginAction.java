package com.tjetc.action;

import com.opensymphony.xwork2.ModelDriven;
import com.tjetc.domain.Student;

public class LoginAction implements ModelDriven<Student> {
    private Student student = new Student();

    @Override
    public Student getModel() {
        return student;
    }

    public String execute() {
        System.out.println(student);
        String studentname = student.getStudentname();
        String password = student.getPassword();
        if ("admin".equals(studentname) && "123".equals(password)) {
            return "success";
        } else {
            return "fail";
        }
    }
}
