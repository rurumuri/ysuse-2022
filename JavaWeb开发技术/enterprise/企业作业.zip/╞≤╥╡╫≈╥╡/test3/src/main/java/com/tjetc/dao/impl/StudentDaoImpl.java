package com.tjetc.dao.impl;

import com.tjetc.dao.StudentDao;
import com.tjetc.domain.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao {

    @Autowired
    private SessionFactory sessionFactory;

    public Student findByStudentname(String studentname) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "from Student where studentname = ?";
        Student student = (Student) session.createQuery(hql).setParameter(0, studentname).uniqueResult();
        return student;
    }

    public List<Student> list(String studentname) {
        Session session = sessionFactory.getCurrentSession();
        List<Student> list = session.createQuery("from Student s where s.studentname like :studentname")
                .setParameter("studentname", "%" + studentname + "%")
                .list();
        return list;
    }

    public boolean add(Student student) {
        Session session = sessionFactory.getCurrentSession();
        session.save(student);
        return true;
    }

    public Student findById(int id) {
        Session session = sessionFactory.getCurrentSession();
        Student student = (Student) session.createQuery("from Student where id = :id")
                .setParameter("id", id)
                .uniqueResult();
        return student;
    }

    public boolean update(Student student) {
        Session session = sessionFactory.getCurrentSession();
        session.update(student);
        return true;
    }

    public boolean delete(Student student) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(student);
        return true;
    }
}
