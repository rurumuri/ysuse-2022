package com.tjetc.action;

import com.opensymphony.xwork2.ModelDriven;
import com.tjetc.domain.Student;
import com.tjetc.service.StudentService;
import com.tjetc.service.impl.StudentServiceImpl;

public class LoginAction implements ModelDriven<Student> {
    private StudentService studentService = new StudentServiceImpl();

    // 创建对象
    private Student student = new Student();

    private String msg;

    public String getMsg() {
        return msg;
    }

    @Override
    public Student getModel() {
        return student;
    }

    // execute方法，处理url请求
    public String execute() {
        System.out.println(student);
        String studentname = student.getStudentname();
        String password = student.getPassword();

        Student student1 = studentService.findByStudentname(studentname);
        if (student1 == null) {
            msg = "用户不存在";
            return "fail";
        } else {
            if (student1.getPassword().equals(password)) {
                return "success";
            } else {
                msg = "密码错误";
                return "fail";
            }
        }
    }
}
