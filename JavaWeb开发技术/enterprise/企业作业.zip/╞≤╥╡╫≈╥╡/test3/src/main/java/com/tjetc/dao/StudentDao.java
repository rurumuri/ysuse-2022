package com.tjetc.dao;

import com.tjetc.domain.Student;

import java.util.List;

public interface StudentDao {
    Student findByStudentname(String studentname);

    List<Student> list(String studentname);
    boolean add(Student student);
    Student findById(int id);
    boolean update(Student student);
    boolean delete(Student student);

}
